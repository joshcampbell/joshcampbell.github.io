txtwiki.js - a javascript library to convert MediaWiki markup to plaintext.
================================================================================

txtwiki.js only has one function, txtwiki.parseWikitext(text).

Depends on QUnit for unit tests.

License
--------------------------------------------------------------------------------
txtwiki.js is released under the MIT license:

http://www.opensource.org/licenses/MIT
